<!-- PHP INCLUDES -->

<?php
    // Set page title
    $pageTitle = 'Order Food';

    include "connect.php";
    include 'Includes/functions/functions.php';
    include "Includes/templates/header.php";
    include "Includes/templates/navbar.php";
    // Getting website settings

    $stmt_web_settings = $con->prepare("SELECT * FROM website_settings");
    $stmt_web_settings->execute();
    $web_settings = $stmt_web_settings->fetchAll();

    $restaurant_name = "";
    $restaurant_email = "";
    $restaurant_address = "";
    $restaurant_phonenumber = "";

    foreach ($web_settings as $option)
    {
        if($option['option_name'] == 'restaurant_name')
        {
            $restaurant_name = $option['option_value'];
        }

        elseif($option['option_name'] == 'restaurant_email')
        {
            $restaurant_email = $option['option_value'];
        }

        elseif($option['option_name'] == 'restaurant_phonenumber')
        {
            $restaurant_phonenumber = $option['option_value'];
        }
        elseif($option['option_name'] == 'restaurant_address')
        {
            $restaurant_address = $option['option_value'];
        }
    }
?>

<!-- ORDER FOOD PAGE STYLE -->

<style type="text/css">
    body
    {
        background: #f7f7f7;
    }

    .text_header
    {
        margin-bottom: 5px;
        font-size: 18px;
        font-weight: bold;
        line-height: 1.5;
        margin-top: 22px;
        text-transform: capitalize;
    }

    .items_tab
    {
        border-radius: 4px;
        background-color: white;
        overflow: hidden;
        box-shadow: 0 0 5px 0 rgba(60, 66, 87, 0.04), 0 0 10px 0 rgba(0, 0, 0, 0.04);
    }

    .itemListElement
    {
        font-size: 14px;
        line-height: 1.29;
        border-bottom: solid 1px #e5e5e5;
        cursor: pointer;
        padding: 16px 12px 18px 12px;
    }

    .item_details
    {
        width: auto;
        display: -webkit-box;
        display: -moz-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        -webkit-flex-direction: row;
        -webkit-box-pack: justify;
        -webkit-justify-content: space-between;
        -webkit-box-align: center;
        -webkit-align-items: center;
    }

    .item_label
    {
        color: #9e8a78;
        border-color: #9e8a78;
        background: white;
        font-size: 12px;
        font-weight: 700;
    }

    .btn-secondary:not(:disabled):not(.disabled).active, .btn-secondary:not(:disabled):not(.disabled):active 
    {
        color: #fff;
        background-color: #9e8a78;
        border-color: #9e8a78;
    }

    .item_select_part
    {
        display: flex;
        -webkit-box-pack: justify;
        justify-content: space-between;
        -webkit-box-align: center;
        align-items: center;
        flex-shrink: 0;
    }

    .select_item_bttn
    {
        width: 55px;
        display: flex;
        margin-left: 30px;
        -webkit-box-pack: end;
        justify-content: flex-end;
    }

    .menu_price_field
    {
        width: auto;
        display: flex;
        margin-left: 30px;
        -webkit-box-align: baseline;
        align-items: baseline;
    }

    .order_food_section
    {
        max-width: 720px;
        margin: 50px auto;
        padding: 0px 15px;
    }

    .item_label.focus,
    .item_label:focus
    {
        outline: none;
        background:initial;
        box-shadow: none;
        color: #9e8a78;
        border-color: #9e8a78;
    }

    .item_label:hover
    {
        color: #fff;
        background-color: #9e8a78;
        border-color: #9e8a78;
    }

    /* Make circles that indicate the steps of the form: */
    .step 
    {
        height: 15px;
        width: 15px;
        margin: 0 2px;
        background-color: #bbbbbb;
        border: none;  
        border-radius: 50%;
        display: inline-block;
        opacity: 0.5;
    }

    .step.active 
    {
        opacity: 1;
    }

    /* Mark the steps that are finished and valid: */
    .step.finish 
    {
        background-color: #4CAF50;
    }


    .order_food_tab
    {
        display: none;
    }

    .next_prev_buttons
    {
        background-color: #4CAF50;
        color: #ffffff;
        border: none;
        padding: 10px 20px;
        font-size: 17px;
        cursor: pointer;
    }

    .client_details_tab  .form-control
    {
        background-color: #fff;
        border-radius: 0;
        padding: 25px 10px;
        box-shadow: none;
        border: 2px solid #eee;
    }

    .client_details_tab  .form-control:focus 
    {
        border-color: #ffc851;
        box-shadow: none;
        outline: none;
    }
    .menu_item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
        padding: 10px;
    }

</style>

<!-- START ORDER FOOD SECTION -->

<section class="order_food_section">

    <?php

        if(isset($_POST['submit_order_food_form']) && $_SERVER['REQUEST_METHOD'] === 'POST')
        {
            // Selected Menus
            $selected_menus = $_POST['selected_menus'];

            // Client Details
            $client_full_name = test_input($_POST['client_full_name']);
            $delivery_address = test_input($_POST['client_delivery_address']);
            $client_phone_number = test_input($_POST['client_phone_number']);
            $client_email = test_input($_POST['client_email']);

            $con->beginTransaction();
            try
            {
                // Insert Client Information
                $stmtClient = $con->prepare("INSERT INTO clients(client_name, client_phone, client_email) VALUES(?, ?, ?)");
                $stmtClient->execute(array($client_full_name, $client_phone_number, $client_email));
                
                // 获取最后插入的客户ID
                $client_id = $con->lastInsertId();
                if (!$client_id) {
                    throw new Exception("Failed to get client ID.");
                }

                // Insert Order Information
                $stmt_order = $con->prepare("INSERT INTO placed_orders(order_time, client_id, delivery_address) VALUES(?, ?, ?)");
                $stmt_order->execute(array(date("Y-m-d H:i"), $client_id, $delivery_address));

                // 获取最后插入的订单ID
                $order_id = $con->lastInsertId();
                if (!$order_id) {
                    throw new Exception("Failed to get order ID.");
                }

                // Insert Menus in the Order
                foreach($selected_menus as $menu)
                {
                    $stmt = $con->prepare("INSERT INTO in_order(order_id, menu_id) VALUES(?, ?)");
                    $stmt->execute(array($order_id, $menu));
                }
                    
                echo "<div class='alert alert-success'>";
                echo "太好了！您的訂單已成功建立。";
                echo "</div>";

                $con->commit();
            }
            catch(Exception $e)
            {
                $con->rollBack();
                echo "<div class='alert alert-danger'>"; 
                echo $e->getMessage();
                echo "</div>";
            }
        }

    ?>

    <!-- ORDER FOOD FORM -->

    <form method="post" id="order_food_form" action="order_food.php">
    
        <!-- SELECT MENUS -->

        <div class="select_menus_tab order_food_tab" id="menus_tab">
        
            <!-- ALERT MESSAGE -->

            <div class="alert alert-danger" role="alert" style="display: none">
                請選擇至少一項商品！
            </div>

            <div class="text_header">
                <span>
                    1. 選擇商品
                </span>
            </div>

            <div>
                <?php
                    $stmt = $con->prepare("Select * from menus");
                    $stmt->execute();
                    $menus = $stmt->fetchAll();
                ?>
                <div class="items_tab">
                    <?php
                        foreach($menus as $menu)
                        {
                    ?>
                        <div class="itemListElement">
                            <div class="item_details">
                                <h6><?php echo '<div>' . $menu['menu_name'] . '</div>'; ?></h6>
                                <h6>
                        <div class="menu_item">
                            <div class="menu_price_field"><?php echo $menu['menu_price']; ?>$</div>
                                </h6>
                                <div class="item_select_part">
                                    <div class="select_item_bttn">
                                        <label class="item_label btn btn-secondary">
                                            <input type="checkbox" name="selected_menus[]" value="<?php echo $menu['menu_id']; ?>" autocomplete="off">選擇
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                        }
                    ?>
                </div>
            </div>
            
        </div>

        <!-- CLIENT DETAILS -->

        <div class="client_details_tab order_food_tab" id="client_details_tab">

            <div class="text_header">
                <span>
                    2. 訂單詳細信息
                </span>
            </div>
        
            <div class="form-group">
                <input type="text" class="form-control" placeholder="你的名字" name="client_full_name" required>
            </div>

            <div class="form-group">
                <input type="text" class="form-control" placeholder="外送地址" name="client_delivery_address" required>
            </div>

            <div class="form-group">
                <input type="text" class="form-control" placeholder="聯繫電話" name="client_phone_number" required>
            </div>

            <div class="form-group">
                <input type="email" class="form-control" placeholder="電子郵件" name="client_email" required>
            </div>

        </div>

        <!-- NEXT AND PREVIOUS BUTTONS -->

        <div style="overflow:auto;">
            <div style="float:right;">
                <button type="button" class="next_prev_buttons" id="prevBtn" onclick="nextPrev(-1)">上一個</button>
                <button type="button" class="next_prev_buttons" id="nextBtn" onclick="nextPrev(1)">下一個</button>
                <button type="submit" class="next_prev_buttons" id="submit_order_food_form" name="submit_order_food_form" style="display: none;">確定</button>
            </div>
        </div>

        <!-- Circles which indicates the steps of the form: -->

        <div style="text-align:center;margin-top:40px;">
            <span class="step"></span>
            <span class="step"></span>
        </div>
    </form>
</section>


<!-- FOOTER BOTTOM -->

<?php include "Includes/templates/footer.php"; ?>


<!-- ORDER FOOD JAVASCRIPT -->

<script>
    var currentTab = 0; // Current tab is set to be the first tab (0)
    showTab(currentTab); // Display the current tab

    function showTab(n)
    {
        // This function will display the specified tab of the form...
        var x = document.getElementsByClassName("order_food_tab");
        x[n].style.display = "block";
        
        //... and fix the Previous/Next buttons:
        if (n == 0)
        {
            document.getElementById("prevBtn").style.display = "none";
        }
        else
        {
            document.getElementById("prevBtn").style.display = "inline";
        }
        if (n == (x.length - 1))
        {
            document.getElementById("nextBtn").style.display = "none";
            document.getElementById("submit_order_food_form").style.display = "inline";
        }
        else
        {
            document.getElementById("nextBtn").style.display = "inline";
            document.getElementById("submit_order_food_form").style.display = "none";
        }
        //... and run a function that displays the correct step indicator:
        fixStepIndicator(n)
    }

    function nextPrev(n)
    {
        // This function will figure out which tab to display
        var x = document.getElementsByClassName("order_food_tab");
        
        // Exit the function if any field in the current tab is invalid:
        if (n == 1 && !validateForm()) return false;
        
        // Hide the current tab:
        x[currentTab].style.display = "none";
        
        // Increase or decrease the current tab by 1:
        currentTab = currentTab + n;
        
        // if you have reached the end of the form...
        if (currentTab >= x.length)
        {
            //...the form gets submitted:
            document.getElementById("order_food_form").submit();
            return false;
        }
        
        // Otherwise, display the correct tab:
        showTab(currentTab);
    }

    function validateForm()
    {
        // This function deals with validation of the form fields
        var x, y, i, valid = true;
        x = document.getElementsByClassName("order_food_tab");
        y = x[currentTab].getElementsByClassName("form-control");
        
        // A loop that checks every input field in the current tab:
        for (i = 0; i < y.length; i++)
        {
            // If a field is empty...
            if (y[i].value == "")
            {
                // add an "invalid" class to the field:
                y[i].className += " invalid";
                // and set the current valid status to false
                valid = false;
            }
        }
        
        // If the valid status is true, mark the step as finished and valid:
        if (valid)
        {
            document.getElementsByClassName("step")[currentTab].className += " finish";
        }
        return valid; // return the valid status
    }

    function fixStepIndicator(n)
    {
        // This function removes the "active" class of all steps...
        var i, x = document.getElementsByClassName("step");
        for (i = 0; i < x.length; i++)
        {
            x[i].className = x[i].className.replace(" active", "");
        }
        //... and adds the "active" class to the current step:
        x[n].className += " active";
    }
</script>
