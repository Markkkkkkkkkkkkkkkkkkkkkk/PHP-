<meta chatset="utf-8">

<form action="sendmail.php" method="post">
請輸入郵件人信箱：<input type="email" name="to"><br/>
請輸入郵件標題：<input type="text" name="subject"><br/>
請輸入郵件內容：<textarea rows="30" cols="30" name="content">
</textarea><br/>

<input type="submit">

</form>