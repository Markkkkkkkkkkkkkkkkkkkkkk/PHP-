<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require '/PHPMailer/src/Exception.php';
require '/PHPMailer/src/PHPMailer.php';
require  '/PHPMailer/src/SMTP.php';

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
//Load Composer's autoloader

$to=$_POST["to"];
$subject=$_POST["subject"];
$content=$_POST["content"];
$content=nl2br($content);

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = false;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'percy200428@gmail.com';                     //SMTP username
    $mail->Password   = 'rjji ybyc bbhq vlip';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
    $mail->CharSet = 'utf-8';
    //Recipients
    $mail->setFrom('percy200428@gmail.com', 'Mailer');
    $mail->addAddress('a1113366@mail.nuk.edu.tw', 'Joe User');     //Add a recipient
    $mail->addAddress('a1113366@mail.nuk.edu.tw');               //Name is optional
    $mail->addAddress($to);
    $mail->addReplyTo('percy200428@gmail.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');
    
    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = '<b>恭喜成功發送</b>';
    $mail->AltBody = '謝謝';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>