<?php
    ob_start();
	session_start();

	$pageTitle = '銷售量';

	if(isset($_SESSION['username_restaurant_qRewacvAqzA']) && isset($_SESSION['password_restaurant_qRewacvAqzA']))
	{
		include 'connect.php';
  		include 'Includes/functions/functions.php'; 
		include 'Includes/templates/header.php';
		include 'Includes/templates/navbar.php';

        ?>

            <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

            <script type="text/javascript">

                var vertical_menu = document.getElementById("vertical-menu");


                var current = vertical_menu.getElementsByClassName("active_link");

                if(current.length > 0)
                {
                    current[0].classList.remove("active_link");   
                }
                
                vertical_menu.getElementsByClassName('gallery_link')[0].className += " active_link";

            </script>

            <style type="text/css">

                .gallery-table td, .gallery-table th 
                {
                    vertical-align: middle;
                    text-align: center;
                }

                .image_gallery
                {
                    width: 50%;
                }

            </style>

        <?php
            
            $stmt = $con->prepare("SELECT * FROM image_gallery");
            $stmt->execute();
            $gallery = $stmt->fetchAll();

        ?>

        <div class="card">
            <div class="card-header">
                <?php echo $pageTitle; ?>
            </div>
            <div class="card-body">
            <meta charset='utf8'>
<?php
$link = @mysqli_connect(
    'localhost',
    'root',
    '',
    'restaurant_website');
    if(!$link){
        echo"資料庫連接錯誤<br/>";
        exit();
    }else{
        echo"資料庫連接成功<br/>";
    }

// 修改查询，合并相同名称的menu_name并计算总量
$sql = "SELECT menu_id, SUM(quantity) as total_quantity FROM in_order GROUP BY menu_id";
$result = mysqli_query($link, $sql);

?>

<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Menu', 'Quantity'],
          <?php
          while($row=mysqli_fetch_assoc($result)){
            $menu_name=$row['menu_id'];
            $total_quantity=$row['total_quantity'];
            echo "['$menu_name', $total_quantity],";
          }
          ?>
        ]);

        var options = {
          title: '當日銷售量',
          pieHole: 0.4,
        };

        var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="donutchart" style="width: 900px; height: 500px;"></div>
  </body>
</html>
            </div>
        </div>

        <?php

        /*** FOOTER BOTTON ***/

        include 'Includes/templates/footer.php';
    }
    else
    {
        header('Location: index.php');
        exit();
    }
?>


<script type="text/javascript">
    // UPLOAD ADD IMAGE GALLERY

    function readURL(input) 
    {
        if (input.files && input.files[0]) 
        {
            var reader = new FileReader();
            reader.onload = function(e) 
            {
                $('#add_gallery_imagePreview').css('background-image', 'url('+e.target.result +')');
                $('#add_gallery_imagePreview').hide();
                $('#add_gallery_imagePreview').fadeIn(650);
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#add_gallery_imageUpload").change(function() 
    {
        readURL(this);
    });

    $('#add_image_bttn').click(function()
    {
        var image_name = $("#image_name_input").val();
        var image = $("#imageUpload").val();
        formdata = new FormData();  

        var do_ = "Add";

        if($.trim(image_name) == "")
        {
            $('#required_image_name').css('display','block');
        }
        else
        {
            $.ajax(
            {
                url:"ajax_files/gallery_ajax.php",
                method:"POST",
                data:{image_name:image_name,image:image,do:do_},
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) 
                {
                    $('#add_image_result').html(data);
                },
                error: function(xhr, status, error) 
                {
                    alert('AN ERROR HAS BEEN ENCOUNTERED WHILE TRYING TO EXECUTE YOUR REQUEST');
                }
            });
        }
    });

</script>

<?php
    // 关闭数据库连接
    mysqli_close($link);
?>
