<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// 从 POST 请求中获取数据
$to = $_POST["to"];
$subject = $_POST["subject"];
$content = $_POST["content"];
$content = nl2br($content); // 将换行符转换为 HTML 换行符

// 创建 PHPMailer 实例
$mail = new PHPMailer(true);

try {
    // 服务器设置
    $mail->SMTPDebug = false;                      // 禁止详细调试输出
    $mail->isSMTP();                               // 使用 SMTP 发送
    $mail->Host       = 'smtp.gmail.com';          // 设置 SMTP 服务器地址
    $mail->SMTPAuth   = true;                      // 启用 SMTP 验证
    $mail->Username   = 'mark20031122@gmail.com';  // SMTP 用户名
    $mail->Password   = 'jost ppoq xoxz zsfv';     // SMTP 密码
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // 启用隐式 TLS 加密
    $mail->Port       = 465;                       // 连接端口
    $mail->CharSet = 'utf-8';                      // 设置字符集

    // 收件人设置
    $mail->setFrom('mark20031122@gmail.com', 'Percy Restaurant');
    $mail->addAddress($to);                         // 添加收件人
    $mail->addReplyTo('mark20031122@gmail.com', 'Information');

    // 内容设置
    $mail->isHTML(true);                            // 设置邮件格式为 HTML
    $mail->Subject = $subject;                      // 设置邮件主题
    $mail->Body    = $content;                      // 设置邮件正文内容
    $mail->AltBody = '謝謝';                       // 设置纯文本备用内容

    // 发送邮件
    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
